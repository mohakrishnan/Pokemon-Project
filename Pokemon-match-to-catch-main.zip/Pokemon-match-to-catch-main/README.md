# Pokemon-match-to-catch
Simple Pokemon themed card matching memory game:  https://emina-ergul.github.io/Pokemon-match-to-catch/
*Only optimised for desktop*
